const express = require('express');
const app = express();
const cors = require('cors');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const userModel = require("./userModel");

mongoose.Promise = global.Promise;
mongoose.connect('mongodb+srv://adminUser:7pH4LDTnmlLMsCSA@cluster0.ngu0t.mongodb.net/newDatabase?retryWrites=true&w=majority', {
  useNewUrlParser: true, useUnifiedTopology: true,
}).then(() => {
  console.log('Database sucessfully connected ')
},
  error => {
    console.log('Database error: ' + error)
  }
)

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cors());

app.get('/user', async (req, res, next) => {
  try {
    const userData = await userModel.find({});
    res.json({ userData: userData });
  } catch (error) {
    console.log(error);
  }
});
app.get('/user/:id', async (req, res, next) => {
  try {
    const user = await userModel.findOne({ userId: req.params.id });
    res.json({ user: user });
  } catch (error) {
    console.log(error);
  }
});
app.put('/user/:id', async (req, res, next) => {
  let amount = req.body.amount;
  let sendAmount = amount * req.body.primaryCurrencyRate;
  try {
    const sendUser = await userModel.findOne({ userId: 1 });
    let id = sendUser._id;
    let userOldAmount = sendUser.amount;
    let userUpdatedAmount = (userOldAmount - amount);
    const sendUserUpdate = await userModel.findByIdAndUpdate(id, { amount: userUpdatedAmount });
    const recieveUser = await userModel.findOne({ userId: req.params.id });
    let objId = recieveUser._id;
    let oldAmount = recieveUser.amount;
    let updatedAmount = (sendAmount + oldAmount);
    const recieveUserUpdate = await userModel.findByIdAndUpdate(objId, { amount: updatedAmount });
    res.json({ recieveUserUpdate: recieveUserUpdate });
  } catch (error) {
    console.log("error")
  }
});
app.post('/user', async (req, res, next) => {
  try {
    const addUser = {
      userId: req.body.userId,
      userName: req.body.userName,
      amount: req.body.amount,
      primaryCurrency: req.body.primaryCurrency,
      primaryCurrencyRate: req.body.primaryCurrencyRate,
    }
    const userData = await userModel.create(addUser);
    res.json({ userData: userData });
  } catch (error) {
    console.log(error);
  }
});

app.listen(3000, () => {
  console.log('server runing port on 3000');
})