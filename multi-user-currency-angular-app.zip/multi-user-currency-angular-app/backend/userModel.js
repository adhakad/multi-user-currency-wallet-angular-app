const mongoose = require('mongoose');
const Schema = mongoose.Schema;
 
let user = new Schema({
  userId: {
    type: Number,
  },
  userName:{
    type: String,
  },
  amount: {
    type: Number,
  },
  primaryCurrency: {
    type: String,
  },
  primaryCurrencyRate: {
    type: Number,
  }


}, {
  collection: 'user'
})
 
module.exports = mongoose.model('user', user)