import { Component, OnInit } from '@angular/core';
import { SendRecieveAmountService } from '../service/send-recieve-amount.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  userId:any;
  sendUser :any = [];
  userList :any = [];
  constructor(private amountService: SendRecieveAmountService) { }

  ngOnInit(): void {
    this.allUserList();
    this.sendUserDetail();
  }
  allUserList() {
    this.amountService.getUsers().subscribe((res: any) => {
      if (res) {
        this.userList = res.userData;
        this.userId=localStorage.getItem('sendUserId');
      }
    });
  }
  sendUserDetail() {
    this.amountService.getById(1).subscribe((res: any) => {
      if (res) {
        localStorage.setItem('sendUserId',res.user.userId);
        localStorage.setItem('sendUserName',res.user.userName);
        localStorage.setItem('sendUserCurrency',res.user.primaryCurrency);
        localStorage.setItem('sendUserAmount',res.user.amount);
        localStorage.setItem('sendUserCurrencyRate',res.user.primaryCurrencyRate);
      }
    }, (error) => {
      console.log("error send user detail")
    })
  }

}
