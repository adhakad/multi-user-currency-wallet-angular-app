import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { SendRecieveAmountService } from '../service/send-recieve-amount.service';
@Component({
  selector: 'app-send-amount',
  templateUrl: './send-amount.component.html',
  styleUrls: ['./send-amount.component.scss']
})
export class SendAmountComponent implements OnInit {

  amount: any;
  userId: any;
  getUserDetail_obj: any = [];
  create_Amount: any = [];
  sendUserId: any;
  sendUserName: any;
  sendUserAmount: any;
  sendUserCurrency: any;
  sendUserCurrencyRate: any;

  constructor(public activatedRoute: ActivatedRoute, private amountService: SendRecieveAmountService, private router: Router) { }

  ngOnInit(): void {

    this.userId = this.activatedRoute.snapshot.paramMap.get('id') ? this.activatedRoute.snapshot.paramMap.get('id') : "";
    this.getUserDetail_obj.slug = this.activatedRoute.snapshot.paramMap.get('id') ? this.activatedRoute.snapshot.paramMap.get('id') : "";
    if (this.getUserDetail_obj.slug) {
      this.recieveUserDetail();
    }
    this.sendUserId = localStorage.getItem("sendUserId");
    this.sendUserAmount = localStorage.getItem("sendUserAmount");
    this.sendUserCurrencyRate = localStorage.getItem("sendUserCurrencyRate");
  }

  recieveUserDetail() {
    this.amountService.getById(this.userId).subscribe((res: any) => {
      if (res) {
        this.create_Amount = JSON.parse(JSON.stringify(res.user));
      }
    }, (error) => {
      console.log("error recieve user detail")
    })
  }

  updateAmount() {
    const data = new FormData();
    let params = {
      userId: this.create_Amount.userId,
      userName: this.create_Amount.userName,
      amount: this.amount,
      primaryCurrency: this.create_Amount.primaryCurrency,
      primaryCurrencyRate: this.create_Amount.primaryCurrencyRate,
      sendUserCurrencyRate: this.sendUserCurrencyRate,
      sendUserId:this.sendUserId
    }
    if (params.amount <= this.sendUserAmount || 0 < this.sendUserAmount ) {
      this.amountService.updateAmount(this.userId, params).subscribe((res: any) => {
        if (res) {
          alert("send amount successfully")
          this.router.navigate(['/dashboard']);
        } else {
          console.log("error1")
        }
      }, (error: any) => {
        error(error.error);
      })
    } else {
      alert("amount is not sufficient")
    }
  }

}