import { TestBed } from '@angular/core/testing';

import { SendRecieveAmountService } from './send-recieve-amount.service';

describe('SendRecieveAmountService', () => {
  let service: SendRecieveAmountService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SendRecieveAmountService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
